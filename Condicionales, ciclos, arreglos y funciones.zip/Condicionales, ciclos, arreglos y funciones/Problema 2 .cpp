#include <iostream>
#include <cmath> // Para abs()
using namespace std;

int main() {
    int sumas[10];

    for (int i = 0; i < 10; ++i) {
        int num;
        cout << "Ingrese número entero [" << i+1 << "]: ";
        cin >> num;

        //Se trabaja con valor absoluto para sumar dígitos correctamente
        int temp = abs(num), suma = 0;
        if (temp == 0) {
            suma = 0;
        } else {
            while (temp > 0) {
                suma += temp % 10;
                temp /= 10;
            }
        }
        sumas[i] = suma;
    }

    cout << "\nArreglo con la suma de dígitos: ";
    for (int i = 0; i < 10; ++i) cout << sumas[i] << " ";
    cout << "\n";
    return 0;
}

