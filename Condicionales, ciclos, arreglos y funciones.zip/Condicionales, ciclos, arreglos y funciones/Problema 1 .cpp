#include <iostream>
using namespace std;

int main() {
    int originales[10], invertidos[10];

    for (int i = 0; i < 10; ++i) {
        int num;
        // Validación de máximo 4 cifras (0 a 9999)
        while (true) {
            cout << "Ingrese número entero (máx 4 cifras) [" << i+1 << "]: ";
            cin >> num;
            if (num >= 0 && num <= 9999) break;
            cout << "Error: El número debe tener entre 0 y 4 cifras.\n";
        }
        originales[i] = num;

        // Lógica de inversión matemática
        int temp = num, inv = 0;
        if (num == 0) {
            inv = 0;
        } else {
            while (temp > 0) {
                inv = inv * 10 + (temp % 10);
                temp /= 10;
            }
        }
        invertidos[i] = inv;
    }

    // Salidas
    cout << "\nArreglo ORIGINAL:  ";
    for (int i = 0; i < 10; ++i) cout << originales[i] << " ";
    cout << "\nArreglo INVERTIDO: ";
    for (int i = 0; i < 10; ++i) cout << invertidos[i] << " ";
    cout << "\n";
    return 0;
}

