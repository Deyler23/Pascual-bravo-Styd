#include <iostream>
using namespace std;

int main() {
    int pos = 0, neg = 0, cero = 0;

    for (int i = 0; i < 10; ++i) {
        double num;
        cout << "Ingrese número [" << i+1 << "]: ";
        cin >> num;

        if (num > 0) pos++;
        else if (num < 0) neg++;
        else cero++;
    }

    cout << "\nNúmeros positivos: " << pos << "\n";
    cout << "Números negativos: " << neg << "\n";
    cout << "Ceros:             " << cero << "\n";
    return 0;
}

