#include <iostream>
#include <cctype> // Para tolower()
using namespace std;

int main() {
    char ch;
    cout << "Ingrese caracteres uno a uno (el programa se detendrá al leer una vocal):\n";

    while (true) {
        cin >> ch; //"cin" omite espacios y saltos de línea automáticamente
        char low = tolower(ch);
        if (low == 'a' || low == 'e' || low == 'i' || low == 'o' || low == 'u') {
            cout << "La primera vocal leída fue: " << ch << "\n";
            break;
        }
    }
    return 0;
}

