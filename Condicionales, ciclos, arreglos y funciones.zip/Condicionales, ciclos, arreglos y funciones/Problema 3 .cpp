#include <iostream>
using namespace std;

int main() {
    for (int tabla = 1; tabla <= 4; ++tabla) {
        cout << "--- Tabla del " << tabla << " ---\n";
        for (int mult = 1; mult <= 10; ++mult) {
            cout << tabla << " x " << mult << " = " << (tabla * mult) << "\n";
        }
        cout << "\n";
    }
    return 0;
}